package Pages;

public class ProductPage extends BasePage {
//    public static final String CHOSEN_BOOK = "//*[contains(text(), 'I Love to Eat')]";
    public static final String IMG_OF_BOOK = "//img[@id = 'FeaturedImage-product-template']";


//    public ProductPage clickOnTheBook() {
//
//        clickElementByXpath(CHOSEN_BOOK);
//        return new ProductPage();
//    }

    public boolean isPageVisible (){
        return elementExists(IMG_OF_BOOK);
    }





}
