package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class BooksResultPage extends BasePage {
    public static final String DROP_DOWN_MENU = "//*[@id= 'SiteNavLabel-books-by-language']";
    public static final String ENGLISH_ONLY = "//a[text() = 'English Only']";
    public static final String ENGLISH_ONLY_HEADER = "//h1[text()= 'English Only']";
//    public static final String CHOSEN_BOOK = "//*[contains(text(), 'I Love to Eat')]";


    public boolean isDropDownMenuVisible() {
        return elementExists(DROP_DOWN_MENU);
    }

    public BooksResultPage chooseEnglishOnly() {
        clickElementByXpath(ENGLISH_ONLY);
        pause();
        return new BooksResultPage();
    }

    public boolean isProductEnglishPageVisible() {
        return elementExists(ENGLISH_ONLY_HEADER);
    }
    private static final String BOOK = "//*[contains(text(),'I Love to Eat Fruits and Vegetables')]";
    public ProductPage chooseBook() {

        findElementByXpath(BOOK).click();

        return new ProductPage();
    }

//    public ProductPage clickOnTheBook() {
////        WebElement element = webDriver.findElement(By.id(CHOSEN_BOOK));
////        Actions actions = new Actions(webDriver);
////        actions.moveToElement(element);
////        actions.perform();
////        WebElement.sendKeys(Keys.DOWN);
//        findElementByXpath(CHOSEN_BOOK).click();
//        return new ProductPage();
//    }


    private void pause() {
        try {
            Thread.sleep(5000);
        } catch (Exception err) {
            System.out.println("Something went wrong");
        }
    }


}
